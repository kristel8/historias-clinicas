export const environment = {
  production: true,
  ApiURL: 'http://192.168.0.128:8094/'
};
