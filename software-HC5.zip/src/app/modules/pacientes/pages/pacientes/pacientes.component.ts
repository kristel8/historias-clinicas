import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IPaciente } from '../models/paciente.interface';
import { PacientesService } from '../services/pacientes.service';
import { MensajesToastService } from 'src/app/shared/services/mensajes-toast.service';
import { MensajesSwalService } from 'src/app/shared/services/mensajes-swal.service';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-pacientes',
  templateUrl: './pacientes.component.html',
  styleUrls: ['./pacientes.component.scss'],
})
export class PacientesComponent implements OnInit {
  pacientes: IPaciente[] = [];
  cols!: any[];
  isLoading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private service: PacientesService,
    private mensajesToast: MensajesToastService,
    private mensajesSwal: MensajesSwalService
  ) {}

  pacienteForm = this.fb.group({
    dni: [null],
    idPaciente: [null],
  });

  ngOnInit(): void {
    this.cols = [
      { icon: 'pi pi-folder', field: 'idPaciente', header: 'ID' },
      { icon: 'pi pi-user', field: 'apellidoPaterno', header: 'Ap. Paterno' },
      { icon: 'pi pi-user', field: 'apellidoMaterno', header: 'Ap. Materno' },
      { icon: 'pi pi-user', field: 'nombres', header: 'Nombres' },
      { icon: 'pi pi-id-card', field: 'dni', header: 'DNI' },
      {
        icon: 'pi pi-calendar',
        field: 'fechaInscrito',
        header: 'Fecha inscrito',
      },
    ];
  }

  buscar(): void {
    const { dni, idPaciente } = this.pacienteForm.getRawValue();

    if (dni || idPaciente) {
      this.isLoading = true;
      this.pacienteForm.disable();

      this.service.getPacienteHistorialByDni(dni).pipe(
        catchError((error) => {
          this.pacienteForm.enable();
          this.isLoading = false;
          this.mensajesSwal.mensajeError('Ha ocurrido un error, intente luego');
          throw error
        })
      ).subscribe((response) => {
        this.isLoading = false;
        this.pacienteForm.enable();
        this.pacientes = response;
        if (response.length === 0) {
          if(dni) this.mensajesToast.showWarn(`No hay paciente con el DNI ${dni}`);
          if(idPaciente) this.mensajesToast.showWarn(`No hay paciente con el Paciente ${idPaciente}`);
        }
      });
    } else {
      this.mensajesToast.showWarn('Complete al menos un campo');
      return;
    }
  }

  limpiar(): void {
    this.pacienteForm.reset();
    this.pacientes = [];
  }

  ver(event: any): void {
    console.log(event);
    this.router.navigate(['ver-paciente'], { relativeTo: this.route });
  }

  eliminar(event: IPaciente): void {
    this.mensajesSwal.mensajePregunta('¿Está seguro de eliminar el paciente?').then((respuesta) => {
      if( respuesta.isConfirmed) {
        this.service.deletePacienteId(event.idPaciente).subscribe();
      }
    })
  }
}
