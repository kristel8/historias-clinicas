import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { IPaciente } from '../models/paciente.interface';
import { Observable } from 'rxjs';
import { IHistoriaClinica } from '../models/historia-clinica.interface';

@Injectable({
  providedIn: 'root'
})
export class PacientesService {

  private URLServicio: string = environment.ApiURL;

  constructor( private httpClient:HttpClient) { }

  getPacienteHistorialByDni(dni: string): Observable<IPaciente[]> {
    return this.httpClient.get<IPaciente[]>(`${this.URLServicio}paciente/getPacienteHistorialByDni?dni=${dni}`);
  }

  getPacienteId(id: number): Observable<IHistoriaClinica[]> {
    return this.httpClient.get<IHistoriaClinica[]>(`${this.URLServicio}paciente/getPaciente?id=${id}`);
  }

  deletePacienteId(id: number): Observable<any> {
    return this.httpClient.post<any>(`${this.URLServicio}paciente/delete`, id);
  }
}
