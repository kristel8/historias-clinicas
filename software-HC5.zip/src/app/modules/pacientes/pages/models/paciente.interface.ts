export interface IPaciente {
  apellidoPaterno: string;
  dni: string;
  idPaciente: any;
  fechaInscrito: string;
  apellidoMaterno: string;
}
