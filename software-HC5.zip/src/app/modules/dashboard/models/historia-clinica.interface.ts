export interface HistoriaClinica {
    id: number;
    apellidoPaterno: string;
    apellidoMaterno: string;
    nombres: string;
    dni: string;
    fechaInscrito: string;
}