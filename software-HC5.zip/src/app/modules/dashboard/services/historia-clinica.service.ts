import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HistoriaClinica } from '../models/historia-clinica.interface';

@Injectable({
  providedIn: 'root'
})
export class HistoriaClinicaService {

  constructor() { }

  getHistoriaClinica(): Observable<HistoriaClinica[]> {
    return of([
      {
         id: 1,
         apellidoPaterno: 'Borja',
         apellidoMaterno: 'Arranza',
         nombres: 'Francisco Jose',
         dni: '75147496',
         fechaInscrito: '20/02/12'
      },
      {
        id: 2,
        apellidoPaterno: 'Calleja',
        apellidoMaterno: 'Concepcion',
        nombres: 'Monserrat Maria',
        dni: '68524917',
        fechaInscrito: '07/10/19'
     },
     {
      id: 3,
      apellidoPaterno: 'Alcala',
      apellidoMaterno: 'Quiles',
      nombres: 'Ander Nicolas',
      dni: '72346859',
      fechaInscrito: '15/04/17'
     },
     {
      id: 4,
      apellidoPaterno: 'Rodriguez',
      apellidoMaterno: 'Vilchez',
      nombres: 'Jose Feliz',
      dni: '76253489',
      fechaInscrito: '10/05/20'
     },
     {
      id: 5,
      apellidoPaterno: 'Sole',
      apellidoMaterno: 'Marquez',
      nombres: 'Virginia Elizabeth',
      dni: '78417413',
      fechaInscrito: '02/07/20'
     },
     {
      id: 6,
      apellidoPaterno: 'Martinez',
      apellidoMaterno: 'Gutierrez',
      nombres: 'Sofia Lina',
      dni: '72343418',
      fechaInscrito: '15/06/15'
     },
     {
      id: 7,
      apellidoPaterno: 'Lopez',
      apellidoMaterno: 'Sanchez',
      nombres: 'Alejandro Meison',
      dni: '78765413',
      fechaInscrito: '03/12/08'
     },
     {
      id: 8,
      apellidoPaterno: 'Rodriguez',
      apellidoMaterno: 'Perez',
      nombres: 'Valentina Harumi',
      dni: '75688901',
      fechaInscrito: '20/09/17'
     },
     {
      id: 9,
      apellidoPaterno: 'Garcia',
      apellidoMaterno: 'Martin',
      nombres: 'Daniel Milton',
      dni: '77654321',
      fechaInscrito: '07/04/17'
     },
     {
      id: 10,
      apellidoPaterno: 'Fernandez',
      apellidoMaterno: 'Ruiz',
      nombres: 'Lucia Jennifer',
      dni: '78456709',
      fechaInscrito: '11/10/99'
     }
    ] as HistoriaClinica[]) 
  }

}
