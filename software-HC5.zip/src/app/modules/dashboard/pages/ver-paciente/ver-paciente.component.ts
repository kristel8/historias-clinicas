import { Component, OnInit } from '@angular/core';
import { Validators, AbstractControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-ver-paciente',
  templateUrl: './ver-paciente.component.html',
  styleUrls: ['./ver-paciente.component.scss']
})
export class VerPacienteComponent implements OnInit {

  historiaClinicaForm = this.fb.group({
    pacienteForm: this.fb.group({
      fechaInscrito: [null, [Validators.required]],
      dni: [null, [Validators.required]],
      id: [null, [Validators.required]],
      apellidoPaterno: [null, [Validators.required]],
      genero: [null, [Validators.required]],
      edad: [null, [Validators.required]],
      apellidoMaterno: [null, [Validators.required]],
      etnia: [null, [Validators.required]],
      correo: [null, [Validators.required]],
      nombres: [null, [Validators.required]],
      estadoCivil: [null, [Validators.required]],
      observaciones: [null, [Validators.required]],
      dniTutor: [null, [Validators.required]],
      apellidoMaternoTutor: [null, [Validators.required]],
      apellidoPaternoTutor: [null, [Validators.required]],
      nombresTutor: [null, [Validators.required]],
    }),
    atencedenteForm: this.fb.group({
      enfermedadesPrevias: [null, [Validators.required]],
      enfermedadesActuales: [null, [Validators.required]],
      alergiaMedicamentos: [null, [Validators.required]],
      lugarNacimiento: [null, [Validators.required]],
      cirugias: [null, [Validators.required]],
    }),
    examenForm: this.fb.group({
      examenGeneral: [null, [Validators.required]],
      estadoPiel: [null, [Validators.required]],
      resumen: [null, [Validators.required]],
      nutricion: [null, [Validators.required]],
      estadoOseo: [null, [Validators.required]],
      hidratacion: [null, [Validators.required]],
      estadoMuscular: [null, [Validators.required]],
      articulacion: [null, [Validators.required]],
      toraxPulmones: [null, [Validators.required]],
      estadoGeneral: [null, [Validators.required]],

    }),
  });


  public get pacienteFormCtrl() : AbstractControl  {
    return this.historiaClinicaForm.get('pacienteForm')!;
  }

  public get atencedenteFormCtrl() : AbstractControl  {
    return this.historiaClinicaForm.get('atencedenteForm')!;
  }

  public get examenFormCtrl() : AbstractControl  {
    return this.historiaClinicaForm.get('examenForm')!;
  }

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
  }

}
