export interface IColumnasTabla {
  field: string;
  subField?:string;
  subField2?: string;
  header: string;
  visibility: boolean;
  formatoFecha: string;
}
