import { FlagsPipe } from './flags.pipe';

describe('FlagsPipe', () => {
  it('create an instance', () => {
    const pipe = new FlagsPipe();
    expect(pipe).toBeTruthy();
  });
});
