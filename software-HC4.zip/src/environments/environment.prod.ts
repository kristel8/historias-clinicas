export const environment = {
  production: true,
  URLTienda: 'http://52.90.244.255:8092/'
};
