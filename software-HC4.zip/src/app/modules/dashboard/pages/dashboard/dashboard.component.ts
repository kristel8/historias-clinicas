import { Component, OnInit } from '@angular/core';
import { HistoriaClinica } from '../../models/historia-clinica.interface';
import { HistoriaClinicaService } from '../../services/historia-clinica.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  historias!: HistoriaClinica[];

  cols!: any[];

  constructor(
    private historiaService: HistoriaClinicaService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.historiaService
      .getHistoriaClinica()
      .subscribe((response) => (this.historias = response));

    this.cols = [
      { icon: 'pi pi-folder', field: 'id', header: 'ID' },
      { icon: 'pi pi-user', field: 'apellidoPaterno', header: 'Ap. Paterno' },
      { icon: 'pi pi-user', field: 'apellidoMaterno', header: 'Ap. Materno' },
      { icon: 'pi pi-user', field: 'nombres', header: 'Nombres' },
      { icon: 'pi pi-id-card', field: 'dni', header: 'DNI' },
      {
        icon: 'pi pi-calendar',
        field: 'fechaInscrito',
        header: 'Fecha inscrito',
      },
    ];
  }

  ver(event: any): void {
    console.log(event);
    this.router.navigate(['ver-paciente'], { relativeTo: this.route });
  }

  eliminar(event: any): void {
    console.log(event);
  }
}
