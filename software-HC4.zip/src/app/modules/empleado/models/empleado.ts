export interface IEmpleado {
  nombre: string,
  apellido: string,
  area: string,
  cargo: string,
  celular: string,
  direccion: string,
  estado: true,
  idEmpleado: number,
  sueldo: number,
  telefono: string,
  tipoDocumento: string,
  numDocumento: string,
}
