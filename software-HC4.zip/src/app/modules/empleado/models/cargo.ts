export interface ICargo {
  descripcion: string,
  estado: boolean,
  idCargo: number
}
