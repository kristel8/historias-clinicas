export interface IArea {
  descripcion: string,
  estado: boolean,
  idArea: number
}
