import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-pacientes',
  templateUrl: './pacientes.component.html',
  styleUrls: ['./pacientes.component.scss']
})
export class PacientesComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
  ) { }

  pacienteForm = this.fb.group({
    nombreCompleto: [null],
    dni: [null],
    idPaciente: [null],
  });

  ngOnInit(): void {
  }

  buscar(): void {
    console.log(this.pacienteForm.getRawValue());
    console.log(this.pacienteForm.value);
  }


  limpiar(): void {
    this.pacienteForm.reset();
  }

}
