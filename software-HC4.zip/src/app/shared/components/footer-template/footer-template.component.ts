import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-template',
  templateUrl: './footer-template.component.html',
  styleUrls: ['./footer-template.component.scss']
})
export class FooterTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
